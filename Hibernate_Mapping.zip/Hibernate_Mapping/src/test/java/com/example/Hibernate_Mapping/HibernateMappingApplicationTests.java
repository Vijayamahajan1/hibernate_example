package com.example.Hibernate_Mapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
